# ControlFlowAI Ver 1.0 - Quiz generation fix

## What changed
- Quiz response parser accepts both `choices` dictionaries and `options` arrays.
- Correct answer may be an A-D letter or the exact text of one of the four options.
- Markdown-fenced JSON and JSON embedded in surrounding text are handled.
- Quiz prompt emphasizes source-grounded questions and checking the answer key.
- Quiz output token budget increased to reduce truncated responses.
- One automatic retry is attempted after invalid/incomplete model output.
- Flask logs the validation reason; API returns a more diagnostic message after both attempts fail.
- Existing text output format is retained for compatibility with the current interactive quiz in `script.js`.

## Install/update on Windows
1. Stop Flask with Ctrl+C.
2. Back up your current `app.py`.
3. Replace `app.py` with the one in this package. Keep your existing `.env` and `users.json` untouched.
4. From the project folder run:
   `\.venv\Scripts\python.exe -m pip install -r requirements.txt`
5. Start Ollama and verify `ollama list` includes `llama3.2:latest`.
6. Start Flask:
   `\.venv\Scripts\python.exe -m flask --app app run --host 127.0.0.1 --port 5000 --debug`
7. Hard-refresh the browser (Ctrl+F5) and try the PDF quiz again.

The archive intentionally excludes `.env` and `users.json`. Preserve those two files from your current installation; `.env.example` is a template only.
